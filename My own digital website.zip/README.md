# My Digital Portfolio

IT (Network and Security) student portfolio. Plain HTML, CSS and JavaScript. No build step.

## Files
- `index.html` - the page structure (the 4 pages load inside it)
- `css/style.css` - colors, layout, animations
- `js/main.js` - **your content is at the top (CONFIG)**, plus page logic
- `assets/images/` - put your photos here
- `CNAME.example` - rename to `CNAME` and put your domain inside (see below)

## Run on your computer
Double-click `index.html`. It opens in your browser.

## Edit your content
Open `js/main.js`. Replace every [bracketed] sample text in `CONFIG`.
Photos: save them in `assets/images/`, then write the path, e.g. `img: "assets/images/me.jpg"`.

## Publish with GitHub Pages
1. Create a GitHub account, then a new **public** repository (e.g. `portfolio`).
2. Click **Add file > Upload files**, drag in everything from this folder, and **Commit changes**.
3. Go to **Settings > Pages**. Under **Branch**, choose `main` and `/ (root)`, then **Save**.
4. After about 1-2 minutes your site is live at `https://YOUR-USERNAME.github.io/REPO-NAME/`.

## Use your DigitalPlat domain
1. In your DigitalPlat dashboard, open your domain's **DNS records**.
2. Add a **CNAME** record: Name `www`, Target `YOUR-USERNAME.github.io`.
3. (Optional, so the bare domain works) add four **A** records for `@` pointing to:
   `185.199.108.153`, `185.199.109.153`, `185.199.110.153`, `185.199.111.153`.
4. In this repo, rename `CNAME.example` to `CNAME` and write your domain on one line, e.g. `www.yourname.dpdns.org`. (Or enter it in **Settings > Pages > Custom domain**.)
5. Wait for DNS to update (minutes to a few hours), then tick **Enforce HTTPS** in Settings > Pages.
6. Open `https://www.yourname.dpdns.org`.
