/* ============================================================
   EDIT HERE: everything on the site comes from this CONFIG.
   Replace the [bracketed] sample text with your own.
   To use a real photo, put your pictures in assets/images/ and write the path, e.g. "img": "assets/images/me.jpg"
   ============================================================ */
const CONFIG = {
  name: "[Your Name]",
  nickname: "[Your Nickname]",
  tagline: "Exploring Technology. Connecting Networks. Securing the Digital World.",
  // social links: change the URLs to your own profiles
  socials: [["GitHub","https://github.com/"],["LinkedIn","https://www.linkedin.com/"],["Facebook","https://www.facebook.com/"]],
  profileImg: "",
  interests: [
    ["🌐","Network Administration","Configuring, monitoring and maintaining reliable networks."],
    ["🛡️","Cybersecurity","Protecting systems and data from threats."],
    ["🔌","Computer Networking","How devices talk to each other, from cables to protocols."],
    ["💻","Information Technology","Solving real problems with the right tools."],
    ["💡","Technology Innovation","Trying new ideas and learning what comes next."]
  ],
  info: [
    ["Full Name","[Your Full Name]"],["Nickname","[Your Nickname]"],["Age","[Your Age]"],
    ["Birthday","[Your Birthday]"],["Address","[Your Address]"],["Gender","[Your Gender]"],
    ["Nationality","[Your Nationality]"],["Course","Bachelor of Science in Information Technology"],
    ["Specialization","Network and Security"],["School","[Your School Name]"],
    ["Hobbies and Interests","[Your Hobbies]"]
  ],
  motto: "[Your favorite quote or motto]",
  bio: "[Sample] I’m an Information Technology student who enjoys figuring out how networks work and how to keep them safe. I like building small labs at home, breaking them on purpose, and learning how to fix them. Replace this paragraph with your own story.",
  goals: "[Sample] Finish my degree with strong grades, earn entry-level networking and security certifications, and build a home lab to practice what I learn.",
  career: "[Sample] Start as a network or systems administrator, grow into a security analyst role, and eventually work toward network security engineering.",
  // categories: Academic, Certificates, Activities, Awards, Seminars, Skills
  achievements: [
    {cat:"Academic",title:"[Sample] Dean’s Lister",year:"2025",desc:"Replace with your own academic achievement.",img:""},
    {cat:"Certificates",title:"[Sample] Cisco Networking Basics",year:"2025",desc:"Completed an introductory networking course.",img:""},
    {cat:"Activities",title:"[Sample] IT Society Member",year:"2024",desc:"Helped organize campus tech events.",img:""},
    {cat:"Awards",title:"[Sample] Best in Programming Fundamentals",year:"2024",desc:"Recognized for top performance in class.",img:""},
    {cat:"Seminars",title:"[Sample] Cybersecurity Awareness Seminar",year:"2025",desc:"Learned about phishing, passwords and safe browsing.",img:""},
    {cat:"Skills",title:"[Sample] Network Setup and Troubleshooting",year:"2026",desc:"Configured small LANs, IP addressing and basic firewalls.",img:""}
  ],
  gallery: ["Certificate 1","Certificate 2","Award photo","Seminar photo","Activity photo","Milestone photo"],
  familyIntro: "My family is one of the most important parts of my life. They are my source of inspiration, strength, motivation, and support as I continue pursuing my dreams and goals.",
  members: [
    {name:"[Mother’s Name]",rel:"Mother",msg:"[Sample] Replace with a short message about her.",img:""},
    {name:"[Father’s Name]",rel:"Father",msg:"[Sample] Replace with a short message about him.",img:""},
    {name:"[Sibling’s Name]",rel:"Sibling",msg:"[Sample] Replace with a short message.",img:""},
    {name:"[Family Member]",rel:"[Relationship]",msg:"[Sample] Replace with a short message.",img:""}
  ],
  memories: ["Family trip","Birthday celebration","Holiday dinner","Graduation day","Weekend together","Favorite memory"]
};

/* ---------- helpers ---------- */
const $ = (s,r=document)=>r.querySelector(s);
const ph = (label,cls="",img="") => `<div class="ph ${cls} ${img?"has":""}" tabindex="0" role="button" aria-label="Add photo: ${label}" ${img?`style="background-image:url('${img}')"`:""}><span>${label}<small>Click to add your photo</small></span></div>`;
const sample = `<p class="tag">Sample content: replace with your own</p>`;

/* ---------- pages ---------- */
const pages = {
home: () => `
<section class="hero"><canvas id="net" aria-hidden="true"></canvas>
  <div class="wrap">
    <div>
      <p class="hi">Hello, Welcome to My Digital Portfolio!</p>
      <h1>Exploring Technology.<span>Connecting Networks.</span><span>Securing the Digital World.</span></h1>
      <p class="lead">I’m ${CONFIG.name}, an Information Technology student specializing in Network and Security. I am passionate about technology, networking, cybersecurity, and continuously developing my skills in the digital world.</p>
      <div class="cta"><a class="btn" href="#achievements">Explore My Portfolio</a><a class="btn ghost" href="#personal">Get to Know Me</a></div>
      <p class="lead" style="font-size:.95rem">Every connection I study teaches me something new about how the digital world holds together, and how to keep it safe.</p>
    </div>
    <div class="pfp">${ph("Profile picture","",CONFIG.profileImg)}</div>
  </div>
</section>
<section><div class="wrap"><h2>What I’m into</h2>
  <div class="grid">${CONFIG.interests.map(i=>`<div class="card"><span class="ico">${i[0]}</span><h3>${i[1]}</h3><p>${i[2]}</p></div>`).join("")}</div>
</div></section>`,

personal: () => `
<div class="wrap pagehead"><h1>Personal Information</h1>${sample}</div>
<section><div class="wrap cols">
  <div>${ph("Profile picture","",CONFIG.profileImg).replace('class="ph ','style="aspect-ratio:1" class="ph ')}</div>
  <div>
    <h2>About me</h2><p class="lead">${CONFIG.bio}</p>
    <p class="motto">“${CONFIG.motto}”</p>
  </div>
</div></section>
<section style="padding-top:0"><div class="wrap">
  <h2>My details</h2>
  <div class="facts">${CONFIG.info.map(f=>`<div class="card fact"><b>${f[0]}</b><span>${f[1]}</span></div>`).join("")}</div>
</div></section>
<section style="padding-top:0"><div class="wrap">
  <h2>Interests and hobbies</h2>
  <div class="grid">${CONFIG.interests.map(i=>`<div class="card"><span class="ico">${i[0]}</span><h3>${i[1]}</h3></div>`).join("")}</div>
</div></section>
<section style="padding-top:0"><div class="wrap grid" style="grid-template-columns:repeat(auto-fit,minmax(280px,1fr))">
  <div class="card"><span class="ico">🎯</span><h3>My goals as an IT student</h3><p>${CONFIG.goals}</p></div>
  <div class="card"><span class="ico">🚀</span><h3>My future career</h3><p>${CONFIG.career}</p></div>
</div></section>`,

achievements: () => {
  const cats = ["All","Academic","Certificates","Activities","Awards","Seminars","Skills"];
  return `
<div class="wrap pagehead"><h1>Achievements</h1>${sample}
  <p class="lead">Academic, personal and extracurricular milestones. Filter by type or scroll the timeline.</p>
  <div class="chips" role="group" aria-label="Filter achievements">${cats.map((c,i)=>`<button class="chip ${i?"":"on"}" data-cat="${c}">${c}</button>`).join("")}</div>
</div>
<div class="wrap"><div class="tl">${CONFIG.achievements.map(a=>`
  <article class="card item" data-cat="${a.cat}">
    ${ph("Certificate or photo","",a.img)}
    <div><span class="meta">${a.cat} · ${a.year}</span><h3>${a.title}</h3><p>${a.desc}</p></div>
  </article>`).join("")}</div></div>
<section><div class="wrap"><h2>Gallery</h2><p class="lead" style="margin-bottom:1.2rem">Click any box to add a picture of a certificate, award or memorable moment.</p>
  <div class="gal">${CONFIG.gallery.map(g=>ph(g)).join("")}</div></div></section>`;},

family: () => `
<div class="wrap pagehead"><h1>My Family</h1>${sample}<blockquote>${CONFIG.familyIntro}</blockquote></div>
<div class="wrap group">${ph("Family group photo")}</div>
<section><div class="wrap"><h2>The people behind me</h2>
  <div class="grid members">${CONFIG.members.map(m=>`<div class="card">${ph("Photo","",m.img)}<h3>${m.name}</h3><p class="rel">${m.rel}</p><p>${m.msg}</p></div>`).join("")}</div>
</div></section>
<section style="padding-top:0"><div class="wrap"><h2>Special moments</h2>
  <div class="gal">${CONFIG.memories.map(g=>ph(g)).join("")}</div></div></section>`
};

/* ---------- router ---------- */
const app = $("#app"), nav = $("#nav"), burger = $(".burger");
function route(){
  const p = pages[location.hash.slice(1)] ? location.hash.slice(1) : "home";
  app.innerHTML = `<div class="page">${pages[p]()}</div>`;
  document.querySelectorAll("nav a").forEach(a=>a.classList.toggle("on",a.dataset.p===p));
  nav.classList.remove("open"); burger.setAttribute("aria-expanded","false");
  window.scrollTo(0,0);
  if(p==="home") startNet();
  document.title = `${CONFIG.name} | ${p==="home"?"Digital Portfolio":p[0].toUpperCase()+p.slice(1)}`;
}
addEventListener("hashchange",route);
burger.onclick = () => burger.setAttribute("aria-expanded", nav.classList.toggle("open"));

/* ---------- interactions ---------- */
app.addEventListener("click",e=>{
  const ch = e.target.closest(".chip");
  if(ch){
    document.querySelectorAll(".chip").forEach(c=>c.classList.toggle("on",c===ch));
    document.querySelectorAll(".item").forEach(i=>i.hidden = ch.dataset.cat!=="All" && i.dataset.cat!==ch.dataset.cat);
    return;
  }
  const box = e.target.closest(".ph");
  if(box){
    const f = document.createElement("input"); f.type="file"; f.accept="image/*";
    f.onchange = () => { if(f.files[0]){ box.style.backgroundImage = `url('${URL.createObjectURL(f.files[0])}')`; box.classList.add("has"); } };
    f.click();
  }
});
app.addEventListener("keydown",e=>{ if((e.key==="Enter"||e.key===" ")&&e.target.classList.contains("ph")){e.preventDefault();e.target.click();} });

/* ---------- hero network animation ---------- */
let raf;
function startNet(){
  cancelAnimationFrame(raf);
  const c = $("#net"); if(!c) return;
  const x = c.getContext("2d"), still = matchMedia("(prefers-reduced-motion:reduce)").matches;
  let w,h,pts=[],m={x:-999,y:-999};
  const size = () => { w=c.width=c.offsetWidth; h=c.height=c.offsetHeight; pts=Array.from({length:Math.min(70,Math.floor(w/16))},()=>({x:Math.random()*w,y:Math.random()*h,vx:(Math.random()-.5)*.4,vy:(Math.random()-.5)*.4})); };
  size(); addEventListener("resize",size);
  c.parentElement.onmousemove = e => { const r=c.getBoundingClientRect(); m.x=e.clientX-r.left; m.y=e.clientY-r.top; };
  c.parentElement.onmouseleave = () => m={x:-999,y:-999};
  (function draw(){
    x.clearRect(0,0,w,h);
    for(const p of pts){
      if(!still){p.x+=p.vx;p.y+=p.vy;}
      if(p.x<0||p.x>w)p.vx*=-1; if(p.y<0||p.y>h)p.vy*=-1;
      x.fillStyle="#27d3ff"; x.beginPath(); x.arc(p.x,p.y,2,0,7); x.fill();
    }
    for(let i=0;i<pts.length;i++)for(let j=i+1;j<pts.length;j++){
      const d=Math.hypot(pts[i].x-pts[j].x,pts[i].y-pts[j].y);
      if(d<130){x.strokeStyle=`rgba(45,140,255,${1-d/130})`;x.beginPath();x.moveTo(pts[i].x,pts[i].y);x.lineTo(pts[j].x,pts[j].y);x.stroke();}
    }
    for(const p of pts){const d=Math.hypot(p.x-m.x,p.y-m.y); if(d<170){x.strokeStyle=`rgba(39,211,255,${1-d/170})`;x.beginPath();x.moveTo(p.x,p.y);x.lineTo(m.x,m.y);x.stroke();}}
    if(!still) raf=requestAnimationFrame(draw);
  })();
}

/* ---------- shared chrome ---------- */
$("#brand").textContent = CONFIG.name;
$("#copy").textContent = `© ${new Date().getFullYear()} ${CONFIG.name}. All rights reserved.`;
$("#soc").innerHTML = CONFIG.socials.map(s=>`<a href="${s[1]}" target="_blank" rel="noopener">${s[0]}</a>`).join("");
route();
